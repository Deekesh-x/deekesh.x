<?php
$uploadDir = "uploads/";

if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
    $fileName = basename($_FILES['files']['name'][$key]);
    $targetPath = $uploadDir . $fileName;

    if (move_uploaded_file($tmp_name, $targetPath)) {
        echo "Uploaded: $fileName<br>";
    } else {
        echo "Failed to upload: $fileName<br>";
    }
}
?>
